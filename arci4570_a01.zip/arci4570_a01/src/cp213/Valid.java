package cp213;

import java.util.Scanner;

public class Valid {
    /**
     * @param args
     * testing
     */
    public static void main(String args[]) {
        String name = "";
        boolean valid= false;
        Scanner keyboard = new Scanner(System.in);
       
        
        System.out.print("Enter a string: ");
        name = keyboard.nextLine();
        valid = isValid(name);
        
        if (valid){
        System.out.printf("'%s' is a valid name.",name);
        } else {
        	System.out.printf("'%s' is not a valid name.", name);
        }
        keyboard.close();

    }

    /**
     * Determines if name is a valid Java variable name. Variables names must
     * start with a letter or an underscore, but cannot be an underscore alone.
     * The rest of the variable name may consist of letters, numbers and
     * underscores.
     *
     * @param name
     *            a string to test as a Java variable name
     * @return true if name is a valid Java variable name, false otherwise
     */
    public static boolean isValid(final String name) {
        boolean validity= true;
    	if (name.length()==1) {
    		if (name.charAt(0) == '_' || Character.isDigit(name.charAt(0))){
    			validity = false;
    		}
        } else {
        	for (int i = 0; i<name.length();++i) {
        		if (!((Character.isAlphabetic(name.charAt(i)))||(Character.isDigit(name.charAt(i)))
        				||(name.charAt(i)=='_'))) {
        			validity = false;
        		}
        	}
        }
    	
        return validity;
    }
}
