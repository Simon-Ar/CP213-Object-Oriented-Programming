package cp213;

import java.util.Scanner;

public class Palindrome {

    /**
     * @param args
     * testing
     */
    public static void main(String[] args) {
        String word="";
        Scanner keyboard = new Scanner (System.in);
        boolean palin;
        
        System.out.print("Enter a string: ");
        word = keyboard.nextLine();
        
        palin = isPalindrome(word);
        
        if (palin)
            System.out.printf("%s is a palindrome", word);
        else
            System.out.printf("%s is not a palindrome.", word);
        keyboard.close();
    }

    /**
     * Determines if s is a palindrome. Ignores case, spaces, digits, and
     * punctuation in the string parameter s.
     *
     * @param s
     *            a string
     * @return true if s is a palindrome, false otherwise
     */
    public static boolean isPalindrome(final String s) {
        
        
        
        String word = s.toLowerCase();
        String newWord="";
        
        for (int i =0; i<word.length(); ++i) {
            if (Character.isAlphabetic(word.charAt(i))) {
              newWord += word.charAt(i);
            }
        }
        boolean palindrome = false;
        int middleLeft = (newWord.length()/ 2)-1;
        int middleRight;
        String left="";
        String right="";
        
        if (newWord.length()%2!= 0)
            middleRight = (newWord.length()/2)+1;
        else
            middleRight = newWord.length()/2;
        for (int i = middleLeft; i>=0; --i) {
            left += newWord.charAt(i);
        } for (int j = middleRight; j<newWord.length();++j) {
            right = right + newWord.charAt(j);
           } if (left.equals(right)) {
            palindrome =true;
        }
        return palindrome;
        }
    }