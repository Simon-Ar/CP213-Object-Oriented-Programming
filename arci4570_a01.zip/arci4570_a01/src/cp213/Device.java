package cp213;

import java.util.Scanner;
import cp213.LeapYear;

public class Device {

    public static final int ORIGINYEAR = 1980;
    
    /**
     * @param args
     * testing
     */
    public static void main(String args[]) {
        Scanner keyboard = new Scanner(System.in);
        int days= 0;
        int years = 0;
        
        System.out.print("Enter number of days: ");
        days = keyboard.nextInt();
        
        years = goodCode(days);
        
        System.out.printf("goodCode - Days: %d = Year: %d%n", days,years);
        years = badCode(days);
        
        System.out.printf("badCode - Days: %d = Year: %d", days,years);
        keyboard.close();

    }

    /**
     * Supposedly calculates the year given days since ORIGINYEAR. Fails on a
     * leap year.
     * 
     * @param days
     *            number of days since January 1, 1980 (int >= 0)
     * @return the year given days
     */
    public static int badCode(int days) {
    	int year = ORIGINYEAR; /* = 1980 */
    	
    	while( days > 365 ) {
    	  if( LeapYear.isLeapYear(year) ) {
    	    if( days > 366 ) {
    	      days -= 366;
    	      year += 1;
    	    }
    	  } else {
    	    days -= 365;
    	    year += 1;
    	  }
    	}
    	return year;
    }

    /**
     * Correctly calculates the year given days since ORIGINYEAR.
     * 
     * @param days
     *            number of days since January 1, 1980 (int >= 0)
     * @return the year
     */
    public static int goodCode(int days) {
    	int year = ORIGINYEAR; /* = 1980 */
    	
    	while( days > 365 ) {
    	  if( LeapYear.isLeapYear(year) ) {
    	    if( days >= 366 ) {
    	      days -= 366;
    	      year += 1;
    	    }
    	  } else {
    	    days -= 365;
    	    year += 1;
    	  }
    	}
    	return year;
}
}
