package cp213;

import java.util.Scanner;

public class LeapYear {
	
    /**
     * @param args
     * testing
     */
    public static void main(String args[]) {
        Scanner keyboard = new Scanner(System.in);
        boolean leapYr = false;
        int year = 0;
        
        System.out.print("Enter a year: ");
        year = keyboard.nextInt();
        
        leapYr = isLeapYear(year);
        if (leapYr) {
        System.out.printf("%d is a leap year",year);
        } else
        	System.out.printf("%d is not a leap year.", year);
        keyboard.close();
    }

    /**
     * Determines whether or not a year is a leap year.
     *
     * @param year
     *            The year to test (int > 0)
     * @return true is year is a leap year, false otherwise.
     */
    public static boolean isLeapYear(final int year) {
       boolean leapYear = false;
       if ((year%4 ==0) && !(year%100==0) ) {
    	   leapYear = true;
       }else if ((year%100==0&&year%400==0)) {
    	   leapYear = true;
       }
       return leapYear;
    }
}