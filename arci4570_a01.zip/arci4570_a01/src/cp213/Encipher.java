package cp213;

import java.util.Scanner;

public class Encipher {

    public static final String ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static final int ALPHA_LENGTH = ALPHA.length();

    /**
     * @param args
     * testing
     */
    public static void main(String[] args) {
        final String CIPHERTEXT = "AVIBROWNZCEFGHJKLMPQSTUXYD"; // for testing substitute method
        Scanner keyboard = new Scanner(System.in);
        int shift= 0;
        String original = "";
        String shifted = "";
        String subed = "";
        
        System.out.print("Enter a string: ");
        original = keyboard.nextLine();
        System.out.print("Enter a shift length: ");
        shift = keyboard.nextInt();
        
        shifted = shift(original,shift);
        subed = substitute(original, CIPHERTEXT);
        
        System.out.printf("Shifted: %s%n",shifted);
        System.out.printf("Substituted: %s%n",subed);
        keyboard.close();

    }

    /**
     * Encipher a string using a shift cipher.
     * 
     * @param s
     *            string to encipher
     * @param n
     *            the number of letters to shift
     * @return the enciphered string
     */
    public static String shift(String s, int n) {   
	    s= s.toUpperCase();
	    String newString ="";
	    for (int i =0; i<s.length();++i) {
	        if (Character.isAlphabetic(s.charAt(i))) {
	            int j = 0;
	            while (newString.length()<=i){
	                if (s.charAt(i)==ALPHA.charAt(j)) {
	                    if (j+n>=26) {
	                      int k = j+n;
	                      k = k-26;
	                      newString += ALPHA.charAt(k);
	                }else
	                    newString += ALPHA.charAt(j+n);
	                } ++j;
	            }
	                } else
	                  newString +=s.charAt(i);
	        }
	    return newString;
    }



    /**
     * Encipher a string using the letter positions in ciphertext.
     * 
     * @param s
     *            string to encipher
     * @param ciphertext
     *            ciphertext alphabet
     * @return the enciphered string
     */
    public static String substitute(String s, String ciphertext) {
        s= s.toUpperCase();
        String newString ="";
        for (int i =0; i<s.length();++i) {
            if (Character.isAlphabetic(s.charAt(i))) {
                int j = 0;
                while (newString.length()<=i){
                    if (s.charAt(i)==ALPHA.charAt(j)) {
                        newString  += ciphertext.charAt(j);
                      }
                      ++j;
                }
                    } else{
                      newString +=s.charAt(i);
                    }
            }
            return newString;
        }
    }