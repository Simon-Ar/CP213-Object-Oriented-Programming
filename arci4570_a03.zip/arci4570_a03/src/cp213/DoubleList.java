package cp213;

/**
 * A simple linked list structure of <code>T</code> objects. Only the
 * <code>T</code> value contained in the list is visible through the standard
 * list methods. Extends the <code>DoubleLink</code> class, which already
 * defines the front node, rear node, length, isEmpty, and iterator.
 *
 * @author - your name here -
 * @author David Brown
 * @version 2019-01-26
 *
 * @param <T>
 *            this data structure value type.
 */
public class DoubleList<T extends Comparable<T>> extends DoubleLink<T> {

	/**
	 * Appends value to the rear of this List.
	 *
	 * @param value
	 *            The value to append.
	 */
	public void append(final T value) {
		if (this.length ==0) {
			final DoubleNode<T> node = new DoubleNode<>(value,null,null);
			this.rear = node;
			this.front = node;
		}else {
			final DoubleNode<T> node = new DoubleNode<>(value,this.rear, null);
			this.rear.setNext(node);
			this.rear = node;
		}
		this.length++;
		return;
	}

	/**
	 * Removes duplicates from this List. The list contains one and only one of
	 * each value formerly present in this List. The first occurrence of each
	 * value is preserved.
	 */
	public void clean() {
		DoubleNode<T> current = this.front;
		DoubleNode<T> mover = this.front.getNext();
		while (current != this.rear ) {
			while (mover!= this.rear) {
				if (current.getValue().equals(mover.getValue()) ) {
					DoubleNode<T> temp = mover.getPrev();
					temp.setNext(mover.getNext()); 
					mover = temp.getNext();
					this.length--;
				}
				mover = mover.getNext();
			}
			current = current.getNext();
			mover = current.getNext();
		}
	}

	/**
	 * Combines contents of two lists into a third. Values are alternated from
	 * the source lists into this List. The source lists are empty when
	 * finished. NOTE: value must not be moved, only nodes.
	 *
	 * @param source1
	 *            The first list to combine with this List.
	 * @param source2
	 *            The second list to combine with this List.
	 */
	public void combine(final DoubleList<T> source1,
			final DoubleList<T> source2) {
		DoubleNode<T> current = new DoubleNode<>(null,null,null);
		DoubleNode<T> node = new DoubleNode<>(null,null,null);
		while (source1.length > 0 && source2.length > 0) {
			if (this.length ==0 ) {
				node = source1.front;
				source1.removeFront();
				node.setNext(null);
				node.setPrev(null);
				this.front = node;
				this.rear = node;
				this.length++;
				current = this.front;
			} else if (source1.length == 0) {
				current.setNext(source2.front);
				this.length++;
				source2.removeFront();
			} else if (source2.length ==0) {
				current.setNext(source1.front);
				this.length++;
				source1.removeFront();
			} else {			
				node = source2.front;
				source2.removeFront();
				node.setNext(null);
				node.setPrev(current);
				this.length++;
				current.setNext(node);
				current = current.getNext();
				node = source1.front;
				source1.removeFront();
				node.setNext(null);
				node.setPrev(current);
				this.length++;
				current.setNext(node);
				current = current.getNext();
			}
		}
		this.rear = current;
		source1.rear = null;
		source2.rear = null;   
	}

	/**
	 * Determines if this List contains key.
	 *
	 * @param key
	 *            The key value to look for.
	 * @return true if key is in this List, false otherwise.
	 */
	public boolean contains(final T key) {
		boolean cont = false;
		DoubleNode<T> current = this.front;
		while (current != this.rear) {
			if (current.getValue().equals(key)) {
				cont = true;
				current= this.rear;
			}else {
				current = current.getNext();
			}
		}
		return cont;
	}

	/**
	 * Finds the number of times key appears in list.
	 *
	 * @param key
	 *            The value to look for.
	 * @return The number of times key appears in this List.
	 */
	public int count(final T key) {
		int count = 0;
		for(T node: this) {
			if (node.equals(key)) {
				count++;
			}
		}	
		return count;
	}

	/**
	 * Finds and returns the value in list that matches key.
	 *
	 * @param key
	 *            The value to search for.
	 * @return The value that matches key, null otherwise.
	 */
	public T find(final T key) {
		T cont= null;
		for(T node: this) {
			if (node.equals(key)) {
				cont = node;
			}
		}
		return cont;	
	}

	/**
	 * Get the nth item in this List.
	 *
	 * @param n
	 *            The index of the item to return.
	 * @return The nth item in this List.
	 * @throws ArrayIndexOutOfBoundsException
	 *             if n is not a valid index.
	 */
	public T get(final int n) throws ArrayIndexOutOfBoundsException {
		if (n > (length -1)) {
			throw new ArrayIndexOutOfBoundsException();
		}else {
			int i = 1;
			DoubleNode<T> current = this.front;
			while(i<n) {
				current = current.getNext();
				i++;
			}
			return current.getValue();
		} 
	}

	/**
	 * Finds the first location of a value by key in this List.
	 *
	 * @param key
	 *            The value to search for.
	 * @return The index of key in this List, -1 otherwise.
	 */
	public int index(final T key) {
		int i = 1;
		DoubleNode<T> current = this.front;
		while(!current.getValue().equals(key) && current!= this.rear) {
			current = current.getNext();
			i++;
		} if (current.getValue()!= key) {
			return -1;
		}else {
			return i;
		}
	}

	/**
	 * Inserts value into this List at index i. If i greater than the length of
	 * this List, append value to the end of this List. Accepts negative values:
	 * -1 is the rear, -2 is second from the end, etc.
	 *
	 * @param i
	 *            The index to insert the new value at.
	 * @param value
	 *            The new value to insert into this List.
	 */
	public void insert(int i, final T value) {
		if (i> (this.length-1)|| i==-1) {
			this.append(value);
		} else if (i <0) {
			DoubleNode<T> current = this.rear;
			DoubleNode<T> prev = this.rear;
			int n = -1;
			while(i < n) {
				prev = current;
				current = current.getPrev();
				n--;
			}
			DoubleNode<T> node = new DoubleNode<>(value,current,prev);
			current.setNext(node);
			prev.setPrev(node);
		}else {
			DoubleNode<T> current = this.front;
			DoubleNode<T> prev = this.front;
			int n = 0;
			while (i> n ) {
				prev = current;
				current = current.getNext();
				n++;
			}
			DoubleNode<T> node = new DoubleNode<>(value, prev, current);
			current.setPrev(node);
			prev.setNext(node);
		}
		this.length++;
	}

	/**
	 * Creates an intersection of two other Lists into this List. Copies value
	 * to this List. Source Lists are unchanged.
	 *
	 * @param source1
	 *            The first List to create an intersection from.
	 * @param source2
	 *            The second List to create an intersection from.
	 */
	public void intersection(final DoubleList<T> source1,
			final DoubleList<T> source2) {
		for(T current : source1){
			for(T checker: source2){
				if (current==checker) {
					this.append(current);
				}
			}
		}
	}

	/**
	 * Determines whether two lists are identical.
	 *
	 * @param that
	 *            The list to compare against this List.
	 * @return true if this List contains the same values in the same order as
	 *         that, false otherwise.
	 */
	public boolean isIdentical(final DoubleList<T> that) {
		boolean isIdent = true;
		DoubleNode<T> dis = this.front;
		DoubleNode<T> dat = that.front;
		while (isIdent && dis != null) {
			if (dis.getValue().compareTo(dat.getValue())!=0 ) {
				isIdent = false;
			}
			dis = dis.getNext();
			dat = dat.getNext();
		}
		return isIdent;
	}

	/**
	 * Finds the maximum value in this List.
	 *
	 * @return The maximum value.
	 */
	public T max() {
		T max = this.front.getValue();
		for (T current : this) {
			if (current.compareTo(max)>0) {
				max = current;
			}
		}
		return max;
	}

	/**
	 * Finds the minimum value in this List.
	 *
	 * @return The minimum value.
	 */
	public T min() {
		T min = this.front.getValue();
		for (T current : this) {
			if (current.compareTo(min)<0) {
				min = current;
			}
		}
		return min;
	}

	/**
	 * Adds a value to the front of this List.
	 *
	 * @param value
	 *            The value to prepend.
	 */
	public void prepend(final T value) {
		final DoubleNode<T> node = new DoubleNode<>(value,null,this.front);
		this.front.setPrev(node);
		this.front = node;
		this.length++;
	}

	/**
	 * Finds, removes, and returns the value in this List that matches key.
	 *
	 * @param key
	 *            The value to search for.
	 * @return The value matching key, null otherwise.
	 */
	public T remove(final T key) {
		T match =null;
		DoubleNode<T> current = this.front;
		DoubleNode<T> prev = this.front;
		while(current != null) {
			if (current.getValue().equals(key)) {
				match = current.getValue();
				if (this.length == 1) {
					this.front = null;
					this.rear = null;
				}else if (current == this.front) {
					this.front = this.front.getNext();
					this.front.setPrev(null);
				}else if (current == this.rear) {
					this.rear= this.rear.getPrev();
					this.rear.setNext(null);
				}else {
					prev.setNext(current.getNext());
					current.getNext().setPrev(prev);
				}
				this.length--;
			}
			prev = current;
			current = current.getNext();
		}
		return match;
	}

	/**
	 * Removes the value at the front of this List.
	 *
	 * @return The value at the front of this List.
	 */
	public T removeFront() {
		T front = this.front.getValue();
		this.front = this.front.getNext();
		if (this.length == 1) {
			this.rear =null;
		}else {
			this.front.setPrev(null);
		}
		this.length--;
		return front;
	}

	/**
	 * Finds and removes all values in this List that match key.
	 *
	 * @param key
	 *            The value to search for.
	 */
	public void removeMany(final T key) {

		while(this.contains(key)) {
			this.remove(key);
		}
	}

	/**
	 * Reverses the order of the values in this List.
	 */
	public void reverse() {
		int i =1;
		DoubleNode<T> oldRear = this.rear;
		T val = null;
		while (i<this.length) {
			val = oldRear.getPrev().getValue();
			this.append(this.remove(val));
			i++;
		}

	}

	/**
	 * Splits the contents of this List into the target Lists. Moves nodes only
	 * - does not move value or call the high-level methods insert or remove.
	 * this List is empty when done. The first half of this List is moved to
	 * target1, and the last half of this List is moved to target2. If the
	 * resulting lengths are not the same, target1 should have one more element
	 * than target2.
	 *
	 * @param target1
	 *            The first List to move nodes to.
	 * @param target2
	 *            The second List to move nodes to.
	 */
	public void split(final DoubleList<T> target1,
			final DoubleList<T> target2) {
		int n = 0;
		DoubleNode<T> current = this.front;
		if (this.length%2 != 0) {
			n = this.length /2+1;
		}else{
			n= this.length/2;
		}if (n<2) {
			current.setNext(null);
			current.setPrev(null);
			target1.front = current;
			target1.rear = current;
			this.front = null;
			target1.length++;
		}else {
			this.front = this.front.getNext();
			this.front.setPrev(null);
			current.setNext(null);
			current.setPrev(null);
			target1.front = current;
			target1.rear = current;
			current= this.front;
			target1.length++;
			this.length--;

			while (this.length >=n) {
				this.front = this.front.getNext();
				if (this.front != null) this.front.setPrev(null);
				current.setNext(null);
				current.setPrev(target1.rear);
				target1.rear.setNext(current);
				target1.rear = current;
				current = this.front;
				target1.length++;
				this.length--;
			}
			this.front = this.front.getNext();
			if (this.front != null) this.front.setPrev(null);
			current.setNext(null);
			current.setPrev(null);
			target2.front = current;
			target2.rear = current;
			current= this.front;
			target2.length++;
			this.length --;
			while (this.length >0) {
				this.front = this.front.getNext();
				current.setNext(null);
				current.setPrev(target2.rear);
				target2.rear.setNext(current);
				target2.rear = current;
				current = this.front;
				target2.length++;
				this.length--;
			}
		}
		this.rear = null;
	}

/**
 * Splits the contents of this List into the target Lists. Moves nodes only
 * - does not move value or call the high-level methods insert or remove.
 * this List is empty when done. Nodes are moved alternately from this List
 * to target1 and target2.
 *
 * @param target1
 *            The first List to move nodes to.
 * @param target2
 *            The second List to move nodes to.
 */
public void splitAlternate(final DoubleList<T> target1,
		final DoubleList<T> target2) {
	int n = 0;
	DoubleNode<T> current = this.front;
	if (this.length%2 != 0) {
		n = this.length /2+1;
	}else{
		n= this.length/2;
	}if (n<2) {
		current.setNext(null);
		current.setPrev(null);
		target1.front = current;
		target1.rear = current;
		this.front = null;
		target1.length++;
	}else {
		this.front = this.front.getNext();
		this.front.setPrev(null);
		current.setNext(null);
		current.setPrev(null);
		target1.front = current;
		target1.rear = current;
		current= this.front;
		target1.length++;

		this.front = this.front.getNext();

		current.setNext(null);
		current.setPrev(null);
		target2.front = current;
		target2.rear = current;
		current= this.front;
		target2.length++;
		this.length -=2;

		while (this.length >=1) {
			this.front = this.front.getNext();
			if (this.front != null) this.front.setPrev(null);
			current.setNext(null);
			current.setPrev(target1.rear);
			target1.rear.setNext(current);
			target1.rear = current;
			current = this.front;
			target1.length++;
			this.length--;

			if (this.length> 0) {

				this.front = this.front.getNext();

				current.setNext(null);
				current.setPrev(target2.rear);
				target2.rear.setNext(current);
				target2.rear = current;
				current = this.front;
				target2.length++;
				this.length--;
			}
		}
		this.rear = null;
	}

}

/**
 * Creates a union of two other Lists into this List. Copies value to this
 * list. source Lists are unchanged.
 *
 * @param source1
 *            The first List to create a union from.
 * @param source2
 *            The second List to create a union from.
 */
public void union(final DoubleList<T> source1,
		final DoubleList<T> source2) {
	for(T node:source1) {
		this.append(node);
	} for (T node:source2) {
		this.append(node);
	}
}
}

