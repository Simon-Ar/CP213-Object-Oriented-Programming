package cp213;

/**
 * A simple linked sorted list structure of <code>T</code> objects. Only the
 * <code>T</code> value contained in the sorted list is visible through the
 * standard sorted list methods. Extends the <code>DoubleLink</code> class,
 * which already defines the front node, rear node, length, isEmpty, and
 * iterator.
 *
 * @author - your name here -
 * @author David Brown
 * @version 2019-01-26
 *
 * @param <T>
 *            this value structure value type.
 */
public class DoubleSortedList<T extends Comparable<T>> extends DoubleLink<T> {

	/**
	 * Removes duplicates from this List. The list contains one and only one of
	 * each value formerly present in this List. The first occurrence of each
	 * value is preserved.
	 */
	public void clean() {
		DoubleNode<T> current = this.front;
		DoubleNode<T> mover = this.front.getNext();
		while (current != this.rear ) {
			while (mover!= this.rear) {
				if (current.getValue().equals(mover.getValue()) ) {
					DoubleNode<T> temp = mover.getPrev();
					temp.setNext(mover.getNext()); 
					mover = temp.getNext();
					this.length--;
				}
				mover = mover.getNext();
			}
			current = current.getNext();
			mover = current.getNext();
		}
	}

	/**
	 * Combines contents of two lists into a third. Values are alternated from
	 * the source lists into this List, but the sorted order is preserved. The
	 * source lists are empty when finished. NOTE: value must not be moved, only
	 * nodes.
	 *
	 * @param source1
	 *            The first list to combine with this List.
	 * @param source2
	 *            The second list to combine with this List.
	 */
	
	public void combine(final DoubleSortedList<T> source1,
			final DoubleSortedList<T> source2) {
		DoubleNode<T> node = new DoubleNode<>(null,null,null);
		while (source1.length > 0 && source2.length > 0) {

			if (this.length ==0 ) {
				node = source1.front;
				source1.removeFront();
				node.setNext(null);
				node.setPrev(null);
				this.front = node;
				this.rear = node;
				this.length++;
			}else { 
				if (source1.length == 0) {
					node = source2.front;
					source2.removeFront();
				} else if (source2.length ==0) {
					node = source1.front;
					source1.removeFront();
				} else {	
					node = source2.front;
					source2.removeFront();
					DoubleNode<T> checker = this.front;
					DoubleNode<T> prevChecker = this.front;	
					while(checker.getValue().compareTo(node.getValue())<1 
							&& checker != this.rear) {
						prevChecker = checker;
						checker = checker.getNext();
					}
					node.setNext(null);
					node.setPrev(null);
					if (checker == this.rear && 
							checker.getValue().compareTo(node.getValue())==-1) {
						node.setPrev(checker);
						this.rear.setNext(node);
						this.rear = node;
					}else {
						node.setPrev(prevChecker);
						node.setNext(checker);
						checker.setPrev(node);
						prevChecker.setNext(node);
					}
					this.length++;
				}
				node = source1.front;
				source1.removeFront();
				DoubleNode<T> checker = this.front;
				DoubleNode<T> prevChecker = this.front;	
				while(checker.getValue().compareTo(node.getValue())<1 
						&& checker != this.rear) {
					prevChecker = checker;
					checker = checker.getNext();
				}
				node.setNext(null);
				node.setPrev(null);
				if (checker == this.rear &&
						checker.getValue().compareTo(node.getValue())==-1){
					node.setPrev(checker);
					this.rear.setNext(node);
					this.rear = node;
				}else {
					node.setPrev(prevChecker);
					node.setNext(checker);
					checker.setPrev(node);
					prevChecker.setNext(node);
				}
				this.length++;
			}
		}	
		source1.rear = null;
		source2.rear = null;   
	}

	/**
	 * Determines if this SortedList contains key.
	 *
	 * @param key
	 *            The key value to look for.
	 * @return true if key is in this SortedList, false otherwise.
	 */
	public boolean contains(final T key) {
		boolean cont = false;
		DoubleNode<T> current = this.front;
		while (current != this.rear) {
			if (current.getValue().equals(key)) {
				cont = true;
				current= this.rear;
			}else {
				current = current.getNext();
			}
		}
		return cont;
	}

	/**
	 * Finds the number of times key appears in list.
	 *
	 * @param key
	 *            The value to look for.
	 * @return The number of times key appears in this SortedList.
	 */
	public int count(final T key) {
		int count = 0;
		for(T node: this) {
			if (node.equals(key)) {
				count++;
			}
		}	
		return count;
	}

	/**
	 * Finds and returns the value in list that matches key.
	 *
	 * @param key
	 *            The value to search for.
	 * @return The value that matches key, null otherwise.
	 */
	public T find(final T key) {
		T cont= null;
		for(T node: this) {
			if (node.equals(key)) {
				cont = node;
			}
		}
		return cont;	
	}

	/**
	 * Get the nth item in this SortedList.
	 *
	 * @param n
	 *            The index of the item to return.
	 * @return The nth item in this SortedList.
	 * @throws ArrayIndexOutOfBoundsException
	 *             if n is not a valid index.
	 */
	public T get(final int n) throws ArrayIndexOutOfBoundsException {
		if (n > (length -1)) {
			throw new ArrayIndexOutOfBoundsException();
		}else {
			DoubleNode<T> current = this.front;
			for(int i =0; i<n;i++) {
				current = current.getNext();
			}
			return current.getValue();
		} 
	}

	/**
	 * Finds the location of a value by key in list.
	 *
	 * @param key
	 *            The value to search for.
	 * @return The index of key in this SortedList, -1 otherwise.
	 */
	public int index(final T key) {
		int i = 1;
		DoubleNode<T> current = this.front;
		while(!current.getValue().equals(key) && current!= this.rear) {
			current = current.getNext();
			i++;
		} if (current.getValue()!= key) {
			return -1;
		}else {
			return i;
		}
	}

	/**
	 * Inserts value into this SortedList. Order is preserved.
	 *
	 * @param value
	 *            The new value to insert into this SortedList.
	 */
	public void insert(final T value) {
		DoubleNode<T> checker = this.front;
		DoubleNode<T> prevChecker = this.front;	
		if (this.length == 0) {
			final DoubleNode<T> node = new DoubleNode<>(value,null,null);
			this.front = node;
			this.rear = node;
		}else {
			while(checker.getValue().compareTo(value)<0 && checker != this.rear) {
				prevChecker = checker;
				checker = checker.getNext();
			}
			if (checker == this.rear &&
					checker.getValue().compareTo(value)==-1){
				final DoubleNode<T> node = new DoubleNode<>(value,checker,null);
				this.rear.setNext(node);
				this.rear = node;
			}else {
				final DoubleNode<T> node = new DoubleNode<>(value,prevChecker,checker);
				checker.setPrev(node);
				prevChecker.setNext(node);
			}
		}
		this.length++;
	}

	/**
	 * Creates an intersection of two other Lists into this SortedList. Copies
	 * value to this SortedList. left and right Lists are unchanged.
	 *
	 * @param left
	 *            The first List to create an intersection from.
	 * @param right
	 *            The second List to create an intersection from.
	 */
	public void intersection(final DoubleSortedList<T> left,
			final DoubleSortedList<T> right) {
		// your code here
	}

	/**
	 * Determines whether two lists are identical.
	 *
	 * @param that
	 *            The list to compare against this SortedList.
	 * @return true if this SortedList contains the same values in the same
	 *         order as that, false otherwise.
	 */
	public boolean isIdentical(final DoubleSortedList<T> that) {
		boolean isIdent = true;
		DoubleNode<T> dis = this.front;
		DoubleNode<T> dat = that.front;
		while (isIdent && dis != null) {
			if (dis.getValue().compareTo(dat.getValue())!=0 ) {
				isIdent = false;
			}
			dis = dis.getNext();
			dat = dat.getNext();
		}
		return isIdent;
	}

	/**
	 * Finds the maximum value in this SortedList.
	 *
	 * @return The maximum value.
	 */
	public T max() {
		return this.rear.getValue();
	}

	/**
	 * Finds the minimum value in this SortedList.
	 *
	 * @return The minimum value.
	 */
	public T min() {
		return this.front.getValue();
	}

	/**
	 * Finds, removes, and returns the value in this SortedList that matches
	 * key.
	 *
	 * @param key
	 *            The value to search for.
	 * @return The value matching key, null otherwise.
	 */
	public T remove(final T key) {
		T match =null;
		DoubleNode<T> current = this.front;
		DoubleNode<T> prev = this.front;
		while(current != this.rear) {			

			if (current.getValue().equals(key)) {
				match = current.getValue();
				if (this.length == 1) {
					this.front = null;
					this.rear = null;
				}else if (current == this.front) {
					this.front = this.front.getNext();
					this.front.setPrev(null);
				}else if (current == this.rear) {
					this.rear= this.rear.getPrev();
					this.rear.setNext(null);
				}else {
					prev.setNext(current.getNext());
					current.getNext().setPrev(prev);
				}
				this.length--;
			}
			prev = current;
			current = current.getNext();
		}
		return match;
	}

	/**
	 * Removes and returns the value at the front of the list.
	 *
	 * @return the value that has been removed.
	 */
	public T removeFront() {
		T front = this.front.getValue();
		this.front = this.front.getNext();
		if (this.length == 1) {
			this.rear =null;
		}else {
			this.front.setPrev(null);
		}
		this.length--;
		return front;
	}

	/**
	 * Finds and removes all values in this SortedList that match key.
	 *
	 * @param key
	 *            The value to search for.
	 */
	public void removeMany(final T key) {
		while(this.contains(key)) {
			this.print();
			this.remove(key);
		}
	}

	/**
	 * Removes and returns the value at the rear of the list.
	 *
	 * @return the value that has been removed.
	 */
	public T removeRear() {
		T rear = this.rear.getValue();
		this.rear = this.rear.getPrev();
		if (this.length == 1) {
			this.front =null;
		}else {
			this.rear.setNext(null);
		}
		this.length--;
		return rear;
	}

	/**
	 * Splits the contents of this List into the target Lists. Moves nodes only
	 * - does not move value or call the high-level methods insert or remove.
	 * this List is empty when done. The first half of this List is moved to
	 * target1, and the last half of this List is moved to target2. If the
	 * resulting lengths are not the same, target1 should have one more element
	 * than target2.
	 *
	 * @param target1
	 *            The first List to move nodes to.
	 * @param target2
	 *            The second List to move nodes to.
	 */
	public void split(final DoubleSortedList<T> target1,
			final DoubleSortedList<T> target2) {
		int n = 0;
		DoubleNode<T> current = this.front;
		if (this.length%2 != 0) {
			n = this.length /2+1;
		}else{
			n= this.length/2;
		}if (n<2) {
			current.setNext(null);
			current.setPrev(null);
			target1.front = current;
			target1.rear = current;
			this.front = null;
			target1.length++;
		}else {
			this.print();
			this.front = this.front.getNext();
			this.front.setPrev(null);
			current.setNext(null);
			current.setPrev(null);
			target1.front = current;
			target1.rear = current;
			current= this.front;
			target1.length++;
			this.length--;

			while (this.length >=n) {
				this.front = this.front.getNext();
				if (this.front != null) this.front.setPrev(null);
				current.setNext(null);
				current.setPrev(target1.rear);
				target1.rear.setNext(current);
				target1.rear = current;
				current = this.front;
				target1.length++;
				this.length--;
			}
			this.front = this.front.getNext();
			if (this.front != null) this.front.setPrev(null);
			current.setNext(null);
			current.setPrev(null);
			target2.front = current;
			target2.rear = current;
			current= this.front;
			target2.length++;
			this.length --;
			while (this.length >0) {
				this.front = this.front.getNext();
				current.setNext(null);
				current.setPrev(target2.rear);
				target2.rear.setNext(current);
				target2.rear = current;
				current = this.front;
				target2.length++;
				this.length--;
			}
		}
		this.rear = null;
	}

	/**
	 * Splits the contents of this List into the target Lists. Moves nodes only
	 * - does not move value or call the high-level methods insert or remove.
	 * this List is empty when done. Nodes are moved alternately from this List
	 * to target1 and target2.
	 *
	 * @param target1
	 *            The first List to move nodes to.
	 * @param target2
	 *            The second List to move nodes to.
	 */
	public void splitAlternate(final DoubleSortedList<T> target1,
			final DoubleSortedList<T> target2) {
		DoubleNode<T> current = this.front;
		DoubleNode<T> current1 = target1.front;
		DoubleNode<T> current2 = target2.front;
		if (this.length<2) {
			current1 = current;
			this.front = null;
		}else {
			this.front = this.front.getNext();
			this.front.setPrev(null);
			current1 = current;
			current= this.front;
			this.front = this.front.getNext();
			this.front.setPrev(null);
			current2 = current;
			current = this.front;
			this.length -=2;
			while (this.length <0) {
				this.front = this.front.getNext();
				this.front.setPrev(null);
				current1.setNext(current);
				current.setPrev(current1);
				current1 = current1.getNext();
				current = this.front;
				if (this.length!= 0) {
					this.front = this.front.getNext();
					this.front.setPrev(null);
					current2.setNext(current);
					current.setPrev(current2);
					current2 = current2.getNext();
					current = this.front;
					this.length--;
				}
				this.length--;
			}
			target1.rear = current1;
			target2.rear = current2;
			this.rear = null;
		}	
	}

	/**
	 * Creates a union of two other Lists into this SortedList. Copies value to
	 * this list. left and right Lists are unchanged.
	 *
	 * @param left
	 *            The first List to create a union from.
	 * @param right
	 *            The second List to create a union from.
	 */
	public void union(final DoubleSortedList<T> left,
			final DoubleSortedList<T> right) {
		for(T node:left) {
			this.insert(node);
		} for (T node:right) {
			this.insert(node);
		}
	}
}
