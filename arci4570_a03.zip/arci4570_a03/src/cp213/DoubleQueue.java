package cp213;

/**
 * A simple linked queue structure of <code>T</code> objects. Only the
 * <code>T</code> value contained in the queue is visible through the standard
 * queue methods. Extends the <code>DoubleLink</code> class, which already
 * defines the front node, rear node, length, isEmpty, and iterator.
 *
 * @author - your name here -
 * @author David Brown
 * @version 2019-01-26
 *
 * @param <T>
 *            this data structure value type.
 */
public class DoubleQueue<T> extends DoubleLink<T> {

	/**
	 * Combines the contents of the left and right Queues into the current
	 * Queue. Moves nodes only - does not move value or call the high-level
	 * methods insert or remove. left and right Queues are empty when done.
	 * Nodes are moved alternately from left and right to this Queue.
	 *
	 * @param source1
	 *            The front Queue to extract nodes from.
	 * @param source2
	 *            The second Queue to extract nodes from.
	 */
	public void combine(final DoubleQueue<T> source1,
			final DoubleQueue<T> source2) {
		DoubleNode<T> current = new DoubleNode<>(null,null,null);
		DoubleNode<T> node = new DoubleNode<>(null,null,null);
		while (source1.length > 0 && source2.length > 0) {
			if (this.length ==0 ) {
				node = source1.front;
				source1.remove();
				node.setNext(null);
				node.setPrev(null);
				this.front = node;
				this.length++;
				current = this.front;
			} else if (source1.length == 0) {
				current.setNext(source2.front);
				this.length++;
				source2.remove();
			} else if (source2.length ==0) {
				current.setNext(source1.front);
				this.length++;
				source1.remove();
			} else {			
				node = source2.front;
				source2.remove();
				node.setNext(null);
				node.setPrev(current);
				this.length++;
				current.setNext(node);
				current = current.getNext();
				node = source1.front;
				source1.remove();
				node.setNext(null);
				node.setPrev(current);
				this.length++;
				current.setNext(node);
				current = current.getNext();
			}
		}
		this.rear = current;
		source1.rear = null;
		source2.rear = null;   
	}

	/**
	 * Adds value to the rear of the queue. Increments the queue size.
	 *
	 * @param value
	 *            The value to added to the rear of the queue.
	 */
	public void insert(final T value) {
		if (this.length ==0) {
			final DoubleNode<T> node = new DoubleNode<>(value,null,null);
			this.rear = node;
			this.front = node;
		}else {
			final DoubleNode<T> node = new DoubleNode<>(value,this.rear, null);
			this.rear.setNext(node);
			this.rear = node;
		}
		this.length++;
		return;
	}

	/**
	 * Returns the front value of the queue and removes that value from the
	 * queue. The next node in the queue becomes the new front node. Decrements
	 * the queue size.
	 *
	 * @return The value at the front of the queue.
	 */
	public T remove() {
		T front = this.front.getValue();
		this.front = this.front.getNext();
		if (this.length == 1) {
			this.rear =null;
		}
		this.length--;
		return front;
	}

	/**
	 * Splits the contents of the current Queue into the left and right Queues.
	 * Moves nodes only - does not move value or call the high-level methods
	 * insert or remove. this Queue is empty when done. Nodes are moved
	 * alternately from this Queue to left and right.
	 *
	 * @param target1
	 *            The first Queue to move nodes to.
	 * @param target2
	 *            The second Queue to move nodes to.
	 */
	public void split(final DoubleQueue<T> target1,
			final DoubleQueue<T> target2) {
		DoubleNode<T> current = this.front;
		if (this.length<2) {
			current.setNext(null);
			current.setPrev(null);
			target1.front = current;
			target1.rear = current;
			this.front = null;
			target1.length++;
		}else {
			this.front = this.front.getNext();
			this.front.setPrev(null);
			current.setNext(null);
			current.setPrev(null);
			target1.front = current;
			target1.rear = current;
			current= this.front;
			target1.length++;

			this.front = this.front.getNext();

			current.setNext(null);
			current.setPrev(null);
			target2.front = current;
			target2.rear = current;
			current= this.front;
			target2.length++;
			this.length -=2;

			while (this.length >=1) {
				this.front = this.front.getNext();
				if (this.front != null) this.front.setPrev(null);
				current.setNext(null);
				current.setPrev(target1.rear);
				target1.rear.setNext(current);
				target1.rear = current;
				current = this.front;
				target1.length++;
				this.length--;

				if (this.length> 0) {

					this.front = this.front.getNext();

					current.setNext(null);
					current.setPrev(target2.rear);
					target2.rear.setNext(current);
					target2.rear = current;
					current = this.front;
					target2.length++;
					this.length--;
				}
			}
			this.rear = null;
		}	

	}
}
