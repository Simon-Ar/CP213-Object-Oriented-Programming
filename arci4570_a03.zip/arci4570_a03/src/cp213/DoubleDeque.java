package cp213;

/**
 * A simple linked deque structure of <code>T</code> objects. Only the
 * <code>T</code> value contained in the deque is visible through the standard
 * deque methods. Extends the <code>DoubleLink</code> class, which already
 * defines the front node, rear node, length, isEmpty, and iterator.
 *
 * @author - your name here -
 * @author David Brown
 * @version 2019-01-26
 *
 * @param <T>
 *            this data structure value type.
 */
public class DoubleDeque<T> extends DoubleLink<T> {

	/**
	 * Adds a value to the front of a deque.
	 *
	 * @param value
	 *            value to add to the front of the deque.
	 */
	public void addFront(final T value) {
		if (this.length==0) {
			final DoubleNode<T> node = new DoubleNode<>(value,null, null);
			this.front = node;
			this.rear = node;
		}else {
			final DoubleNode<T> node = new DoubleNode<>(value,null, this.front);
			this.front.setPrev(node);
			this.front = node;
		}
		this.length++;
		return;
	}
	
	
	/**
	 * Adds a value to the rear of a deque.
	 *
	 * @param value
	 *            value to add to the rear of the deque.
	 */
	public void addRear(final T value) {
		if (this.length ==0) {
			final DoubleNode<T> node = new DoubleNode<>(value,null,null);
			this.rear = node;
			this.front = node;
		}else {
			final DoubleNode<T> node = new DoubleNode<>(value,this.rear, null);
			this.rear.setNext(node);
			this.rear = node;
		}
		this.length++;
		return;
	}

	/**
	 * Returns the value at the front of a deque.
	 *
	 * @return the value at the front of the deque.
	 */
	public T peekFront() {
		return this.front.getValue();
	}

	/**
	 * Returns the value at the rear of a deque.
	 *
	 * @return the value at the rear of the deque.
	 */
	public T peekRear() {
		return this.rear.getValue();
	}

	/**
	 * Removes and returns the value at the front of a deque.
	 *
	 * @return the value that has been removed.
	 */
	public T removeFront() {
		if (this.length == 1) {
			DoubleNode<T> node  = this.front;
			this.front = null;
			this.rear = null;
			this.length--;
			return node.getValue();

		}else {
			DoubleNode<T> node  = this.front;
			this.front = this.front.getNext();
			this.front.setPrev(null);
			this.length--;
			return node.getValue();
		}
	}

	/**
	 * Removes and returns the value at the rear of a deque.
	 *
	 * @return the value that has been removed.
	 */
	public T removeRear() {
		if (this.length ==1) {
			DoubleNode<T> node = this.rear;
			this.rear = null;
			this.length--;
			return node.getValue();
		}else {
			DoubleNode<T> node  = this.rear;
			this.rear = this.rear.getPrev();
			this.rear.setNext(null);
			this.length--;
			return node.getValue();	
		}
	}
}
