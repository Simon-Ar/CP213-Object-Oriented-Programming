package cp213;

public class Main {

	public static void main(String[] args) {
		System.out.printf("------------------%s-----------------\n", "Deque");
		DoubleDeque<Integer> deque = new DoubleDeque<Integer>();

		System.out.println("Deque insert");
		for (int i = 0; i<=10;i++) {
			System.out.printf("%d, ",i);
			deque.addFront(i);
		}
		System.out.println("\nFront: " + deque.peekFront());
		System.out.println("Rear: " + deque.peekRear());
		System.out.println("Deque Remove:");
		while(deque.getLength() >0) {
			System.out.printf("%d, ",deque.removeFront());
		}

		System.out.printf("\n------------------%s-----------------\n", "Queue");
		DoubleQueue<Integer> queue = new DoubleQueue<Integer>();
		DoubleQueue<Integer> queue1 = new DoubleQueue<Integer>();
		DoubleQueue<Integer> queue2 = new DoubleQueue<Integer>();
		System.out.println("Queue insert");
		for (int i = 0; i<=10;i++) {
			System.out.printf("%d, ",i);
			queue.insert(i);
		}
		System.out.println("\nSplit: ");
		queue.split(queue1,queue2);
		System.out.println("Combine: ");
		queue.combine(queue1, queue2);
		System.out.println("Queue Remove:");
		while(queue.getLength() >0) {
			System.out.printf("%d, ",queue.remove());
		}

		System.out.printf("\n------------------%s-----------------\n", "List");
		DoubleList<Integer> List = new DoubleList<Integer>();
		DoubleList<Integer> List1 = new DoubleList<Integer>();
		DoubleList<Integer> List2 = new DoubleList<Integer>();
		System.out.println("List insert");
		for (int i = 0; i<=10;i++) {
			System.out.printf("%d, ",i);
			List.append(i);
		}
		System.out.println("\nSplit: ");
		List.split(List1,List2);
		List.print();
		List1.print();
		List2.print();
		System.out.println("Is Identical: " + List1.isIdentical(List2));
		System.out.println("Combine + Insert: ");
		List.combine(List1, List2);
		List.insert(6, 4);
		System.out.println("Index 4 + Prepend: " + List.index(4));
		List.prepend(7);
		List.print();
		List.clean();
		System.out.println("Clean + Remove 7: ");
		List.remove(7);
		List.print();
		List.prepend(7);
		List.prepend(7);
		List.prepend(7);
		List.print();
		System.out.println("Find 7: " + List.find(7));
		List.removeMany(7);
		System.out.print("Remove Many 7: "); List.print();
		List.reverse();
		System.out.print("Reverse: "); List.print();
		System.out.println("Contains 15: "+ List.contains(15));
		System.out.println("Count 4: " + List.count(4));
		System.out.println("Find 15: " + List.find(15));
		System.out.println("Get 3: " + List.get(3));
		System.out.println("Max + Min: " + List.max() +","+ List.min());
		System.out.println("List Remove");
		while(List.getLength() >0) {
			System.out.printf("%d, ",List.removeFront());
		}
		System.out.printf("\n------------------%s-----------------\n", "Sorted List");
		DoubleSortedList<Integer> sList = new DoubleSortedList<Integer>();
		DoubleSortedList<Integer> sList1 = new DoubleSortedList<Integer>();
		DoubleSortedList<Integer> sList2 = new DoubleSortedList<Integer>();
		System.out.println("Sorted List insert");
		for (int i = 0; i<=10;i++) {
			System.out.printf("%d, ",i);
			sList.insert(i);
		}
		System.out.println("\nSplit: ");
		sList.split(sList1,sList2);
		sList.print();
		sList1.print();
		sList2.print();
		System.out.println("Is Identical: " + sList1.isIdentical(sList2));
		System.out.println("Combine + Insert: ");
		sList.combine(sList1, sList2);
		sList.insert(6);
		System.out.println("Index 4: " + sList.index(4));
		sList.print();
		sList.clean();
		System.out.println("Clean + Remove 7: ");
		sList.remove(7);
		sList.print();
		sList.insert(7);
		sList.print();
		System.out.println("Find 7: " + sList.find(7));
		sList.removeMany(7);
		System.out.print("Remove Many 7: "); sList.print();
		//System.out.print("Reverse: "); sList.print();
		System.out.println("Contains 15: "+ sList.contains(15));
		System.out.println("Count 4: " + sList.count(4));
		System.out.println("Find 15: " + sList.find(15));
		System.out.println("Get 3: " + sList.get(3));
		System.out.println("Max + Min: " + sList.max() +","+ sList.min());
		System.out.println("Sorted List Remove");
		while(sList.getLength() >0) {
			System.out.printf("%d, ",sList.removeFront());
		}
	}
}

