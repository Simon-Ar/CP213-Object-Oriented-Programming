package cp213;
/**
 * Implements a Binary Search Tree.
 *
 * - Simon Arcila -
 *
 * @version 2019-01-26
 *
 * @param <T> The data to store in the tree.
 */
public class PopularityTree<T extends Comparable<T>> extends BST<T>{

	@Override
	public void insert(final T data) {
		this.root = insert(data, this.root,null);
	}

	private TreeNode<T> insert(final T data, TreeNode<T> root, TreeNode<T> parent) {
		TreeNode<T> x = new TreeNode<>(data);
		if (root== null) {
			root= x;
			this.size++;
			x.incrementCount();
		}
		else if (x.getData().compareTo(root.getData())<0) {
			if(root.getLeft()==null)
				root.setLeft(x);
			else
				insert(data,root.getLeft(),root);
		}
		else if (x.getData().compareTo(root.getData())>0) {
			if (root.getRight()==null)
				root.setRight(x);
			else
				insert(data,root.getRight(),root);
		}
		else if (x.getData().compareTo(root.getData())== 0)
			root.incrementCount();

		if ((root.getLeft()!= null) && (root.getLeft().getCount()>root.getCount()))
			root = rotateRight(root,parent);
		else if ((root.getRight()!= null) && (root.getRight().getCount()>root.getCount()))
			root = rotateLeft(root,parent);

		return root;
	}


	private TreeNode<T> rotateRight(TreeNode<T> x,TreeNode<T> parent){
		TreeNode<T> y = x.getLeft();
		TreeNode<T> T2 = y.getRight();
		y.setRight(x);
		x.setLeft(T2);
		if (parent!=null) {
			if (parent.getLeft() == x)
				parent.setLeft(y);
			else
				parent.setRight(y);
			parent.updateHeight();
		}
		x.updateHeight();
		y.updateHeight();
		return y;
	}

	private TreeNode<T> rotateLeft(TreeNode<T> y,TreeNode<T> parent){

		TreeNode<T> x = y.getRight();
		TreeNode<T> T2 = x.getLeft();
		x.setLeft(y);
		y.setRight(T2);
		if (parent!=null) {
			if (parent.getLeft() == y)
				parent.setLeft(x);
			else
				parent.setRight(x);
			parent.updateHeight();
		}
		x.updateHeight();
		y.updateHeight();
		return x;
	}
}
