package cp213;

public class Main {

	public static void main(String[] args) {
		int[] nums = {1,2,3,4,5,6,7,8,9};
		BST<Integer> bst = new BST<Integer>();
		BST<Integer> bst2 = new BST<Integer>();
		TreeNode<Integer>[] bstArray;
		for(int i:nums) {
			bst.insert(i);
			bst2.insert(i);
		}
		if (!bst.isEmpty()) {
			System.out.printf("Height: %d, Size: %d\n",bst.getHeight(),bst.getSize());
			System.out.println(bst.isValid());
			System.out.println(bst.equals(bst2));
			System.out.println(bst.contains(1));
			bstArray = bst.toArray();
			//for(TreeNode<Integer> i:bstArray) {
				//System.out.print("H:" + bst.nodeHeight(i) + "," + i.getData() + "\n");
			//}
		}
		PopularityTree<Integer> pt = new PopularityTree<Integer>();
		TreeNode<Integer>[] ptArray;
		for (int i:nums) {
			pt.insert(i);
		}
		ptArray = pt.toArray();
		pt.preorder();
		
		System.out.println("-------------------------------------------------");
		AVL<Integer> avl = new AVL<Integer>();
		TreeNode<Integer>[] avlArray;
		for (int i:nums) {
			avl.insert(i);
		}
		avl.preorder();
		System.out.println(avl.isValid());
		
	}

}
