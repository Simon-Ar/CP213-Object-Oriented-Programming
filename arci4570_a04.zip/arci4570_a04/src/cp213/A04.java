package cp213;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Process text files with three kinds of trees to determine their relative
 * efficiency.
 *
 * @author your name here
 * @version 2019-03-19
 */
public class A04 {

	/**
	 * Program for Assignment 4.
	 *
	 * @param args
	 *            unused
	 * @throws IOException
	 *             If error on files.
	 */

	public static void main(final String[] args) throws IOException {
		File trainer = new File("src/cp213/decline.txt");
		File tester = new File("src/cp213/miserables.txt");

		BST<Character> bst = new BST<Character>();
		PopularityTree<Character> pt = new PopularityTree<Character>();
		AVL<Character> avl = new AVL<Character>();
		
		System.out.println("Training File: "+ trainer.getName());
		System.out.println("Comparisions File: "+ tester.getName());
		System.out.println("----------------------------------------");
		train(bst,trainer);
		characterTable(bst);
		System.out.println("----------------------------------------");
		System.out.printf("Tree Type: BST\nTraining...\n");
		train(bst,trainer);
		System.out.printf("Valid: %b\n"
				+ "Height: %d\n"
				+ "Retrieving...\n", bst.isValid(),bst.getHeight());
		retrieve(bst,tester);
		int a = bst.getComparisons();
		System.out.printf("Comparisons: %,d\n", a);
		System.out.println("----------------------------------------");
		System.out.printf("Tree Type: Popularity Tree\nTraining...\n");
		train(pt,trainer);
		System.out.printf("Valid: %b\n"
				+ "Height: %d\n"
				+ "Retrieving...\n", pt.isValid(),pt.getHeight());
		retrieve(pt,tester);
		int b = pt.getComparisons();
		System.out.printf("Comparisons: %,d\n", pt.getComparisons());
		System.out.println("----------------------------------------");
		System.out.printf("Tree Type: AVL\nTraining...\n");
		train(avl,trainer);
		System.out.printf("Valid: %b\n"
				+ "Height: %d\n"
				+ "Retrieving...\n", avl.isValid(),avl.getHeight());
		retrieve(avl,tester);
		int c = avl.getComparisons();
		System.out.printf("Comparisons: %,d\n", avl.getComparisons());
		System.out.println("----------------------------------------");
		System.out.printf("Tree with minimum comparisons: ");
		if  ( Math.min(a, Math.min(b, c))==a)
			System.out.print("BST");
		else if ( Math.min(a, Math.min(b, c))==b)
			System.out.print("Popularity Tree");
		else
			System.out.print("AVL");
	}

	/**
	 * Print a formatted table of character counts and percentages.
	 *
	 * @param tree The BST to generate the table from.
	 */
	public static void characterTable(final BST<Character> tree) {

		System.out.println("Character Table for Training File");
		System.out.printf("\n%s%9s%8s\n","Char", "Count","Percent");
		char[] alpha = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
		TreeNode<Character>[] treeArray = tree.toArray();
		float totalComps=0;
		for (TreeNode<Character> i:treeArray) {
			totalComps += i.getCount();
		}
		for(int i =0;i<treeArray.length;i++) {
			for(int j =0;j<treeArray.length;j++) {
				if(treeArray[i].getData().compareTo(treeArray[j].getData())<0) {
					TreeNode<Character> temp = treeArray[j];
					treeArray[j] = treeArray[i];
					treeArray[i] = temp;
				}
			}

		}
		for (TreeNode<Character> i:treeArray) {
			System.out.printf("%c%9d%8.2f\n",i.getData(),i.getCount(),(i.getCount()/totalComps)*100);
		}
	}

	/**
	 * Determine the number of comparisons to retrieve the contents of a file
	 * from a tree. Reset the number of comparisons, then attempt to retrieve
	 * every letter in the file from tree. All letters must be converted to
	 * upper case.
	 *
	 * @param tree
	 *            The BST to process.
	 * @param file
	 *            The file to process.
	 * @return The number of comparisons necessary to find every letter in file
	 *         in tree.
	 * @throws IOException 
	 */
	public static int retrieve(final BST<Character> tree, final File file)
			throws IOException {
		tree.resetComparisons();
		FileInputStream fis  = new FileInputStream(file);

		while (fis.available()>0) {
			char text = (char) fis.read();
			if ((text >= 'a' && text <= 'z') || (text >= 'A' && text <= 'Z'))
				tree.retrieve(Character.toUpperCase(text));
		}
		fis.close();

		return tree.getComparisons();
	}

	/**
	 * Train a tree by inserting all letters from a file into the tree. Letters
	 * must be converted to upper-case. Non-letters are ignored.
	 *
	 * @param tree
	 *            The BST to train.
	 * @param file
	 *            The file to read into the tree.
	 * @throws IOException 
	 */
	public static void train(final BST<Character> tree, final File file)
			throws IOException {

		FileInputStream fis  = new FileInputStream(file);

		while (fis.available()>0) {
			char text = (char) fis.read();
			if ((text >= 'a' && text <= 'z') || (text >= 'A' && text <= 'Z'))
				tree.insert(Character.toUpperCase(text));
		}
		fis.close();
		return;
	}
}
