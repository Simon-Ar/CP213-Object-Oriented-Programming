package cp213;
/**
 * Implements a Binary Search Tree.
 *
 * - Simon Arcila -
 *
 * @version 2019-01-26
 *
 * @param <T> The data to store in the tree.
 */
public class AVL <T extends Comparable<T>> extends BST<T>{


	@Override
	public void insert(final T data) {
		this.root = insert(data, this.root,null);
	}

	private TreeNode<T> insert(T data, TreeNode<T> root,TreeNode<T> parent){
		TreeNode <T> x = new TreeNode<>(data);
		if (root== null) {
			root= x;
			x.incrementCount();
			this.size++;
		}
		else if (x.getData().compareTo(root.getData())<0) {
			if(root.getLeft()==null)
				root.setLeft(x);
			else
				insert(data,root.getLeft(),root);
		}
		else if (x.getData().compareTo(root.getData())>0) {
			if (root.getRight()==null)
				root.setRight(x);
			else
				insert(data,root.getRight(),root);
		}else if (x.getData().compareTo(root.getData())==0)
			root.incrementCount();
		root.updateHeight();

		int balance = balance(root);
		if (balance >1 && balance(root.getLeft())<0) { //LeftRight
			root.setLeft(rotateLeft(root.getLeft(),root));
			root = rotateRight(root,parent);
		} else if (balance <-1 && balance(root.getRight())>0) { //RightLeft
			root.setRight(rotateRight(root.getRight(),root));
			root = rotateLeft(root,parent);
		}else if (balance>1) // Right
			root = rotateRight(root,parent);
		else if(balance <-1) // Left
			root = rotateLeft(root,parent);
		return root;
	}

	private int balance(TreeNode<T> node) {
		if (node == null)
			return 0;
		else
			return nodeHeight(node.getLeft()) - nodeHeight(node.getRight());
	}

	private TreeNode<T> rotateRight(TreeNode<T> x,TreeNode<T> parent){
		TreeNode<T> y = x.getLeft();
		TreeNode<T> T2 = y.getRight();
		y.setRight(x);
		x.setLeft(T2);
		if (parent!=null) {
			if (parent.getLeft() == x)
				parent.setLeft(y);
			else
				parent.setRight(y);
			parent.updateHeight();
		}
		x.updateHeight();
		y.updateHeight();
		return y;
	}

	private TreeNode<T> rotateLeft(TreeNode<T> y,TreeNode<T> parent){

		TreeNode<T> x = y.getRight();
		TreeNode<T> T2 = x.getLeft();
		x.setLeft(y);
		y.setRight(T2);
		if (parent!=null) {
			if (parent.getLeft() == y)
				parent.setLeft(x);
			else
				parent.setRight(x);
			parent.updateHeight();
		}
		x.updateHeight();
		y.updateHeight();
		return x;
	}


	@Override
	public boolean isValid() {
		return isValid(this.root);
	}

	private boolean isValid(TreeNode<T> root) {
		if (root == null)
			return true;
		else if (balance(root)>1||balance(root)<-1)
			return false;

		boolean isAvl = isValid(root.getLeft())&&isValid(root.getRight());
		return isAvl;
	}
}
