package cp213;

import java.io.FileNotFoundException;
import java.io.PrintStream;

/**
 * The Food class definition.
 * 
 * @author your name here
 * @version 2019-01-24
 */
public class Food implements Comparable<Food> {

	// Constants
	public static final String ORIGIN[] = { "Canadian", "Chinese", "Indian",
			"Ethiopian", "Mexican", "Greek", "Japanese", "Italian", "American",
			"Scottish", "New Zealand", "English" };

	/**
	 * Creates a string list of food origins in the format
	 * 
	 * <pre>
	 * 0 Canadian 
	 * 1 Chinese 
	 * 2 Indian
	 * ...
	 * </pre>
	 *
	 * @return A formatted numbered string of valid food origins.
	 */
	public static String origins() {
		String orgns="";
		for (int i = 0;i<ORIGIN.length;i++) {
			orgns += String.format("%d %s", i,ORIGIN[i]);
		}

		return orgns;
	}

	// Attributes
	private String name = "";
	private int origin = 0;
	private boolean vegetarian = false;
	private int calories = 0;

	/**
	 * Food constructor.
	 *
	 * @param name
	 *            food name
	 * @param origin
	 *            food origin code
	 * @param vegetarian
	 *            whether food is vegetarian
	 * @param calories
	 *            caloric content of food
	 */
	public Food(final String name, final int origin, final boolean vegetarian,
			final int calories) {
		this.name = name;
		this.origin = origin;
		this.vegetarian = vegetarian;
		this.calories = calories;

	}

	/*
	 * (non-Javadoc) Compares this Food against that Food. Returns -1 if this Food
	 * comes before that Food, 1 if this Food comes after that Food, and 0 if
	 * the two Foods are the same.
	 * 
	 * Foods are compared first by name, then by origin.
	 *
	 * @see java.lang.Comparable//compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(final Food that) {
		if (this.name.compareTo(that.name)==0) {
			if (this.origin < that.origin) {
				return -1;
			} else if (this.origin > that.origin) {
				return 1;
			} else {
				return 0;
			}
		}
		return this.name.compareTo(that.name);
	}

	/**
	 * @return calories
	 */
	public int getCalories() {

		return this.calories;

	}

	/**
	 * @return name
	 */
	public String getName() {

		return this.name;

	}

	/**
	 * @return origin
	 */
	public int getOrigin() {

		return this.origin;

	}

	/**
	 * @return the string version of origin
	 */
	public String getOriginString() {

		return ORIGIN[this.origin];

	}

	/*
	 * (non-Javadoc) Generates a hash value from a food name.
	 *
	 * @see java.lang.Object//hashCode()
	 */
	@Override
	public int hashCode() {

		return this.name.hashCode();

	}

	/**
	 * @return vegetarian
	 */
	public boolean isVegetarian() {

		return this.vegetarian;

	}

	/**
	 * Creates a formatted string of food key data.
	 *
	 * @return the contents of Food as a key string.
	 */
	public String key() {

		return String.format("%s, %d",this.name,this.origin);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object//toString() Creates a formatted string of food
	 * data.
	 */
	@Override
	public String toString() {
		String string = String.format("Name:       %s%n", this.name);
		string += String.format("Origin:     %s%n", Food.ORIGIN[this.origin]);
		string += String.format("Vegetarian: %s%n", this.vegetarian);
		string += String.format("Calories:   %d%n", this.calories);
		return string;
	}
		/**
		 * Writes a single line of food data to an open PrintStream. The contents of
		 * food are written as a string in the format name|origin|vegetarian to ps.
		 *
		 * @param ps The PrintStream to write to.
		 * @throws FileNotFoundException if file not found
		 */
		public void write(final PrintStream ps) {
			final String string = String.format("%s|%s|%b|%d", this.name,
					this.origin, this.vegetarian, this.calories);
			ps.println(string);
			return;
		}
	}
